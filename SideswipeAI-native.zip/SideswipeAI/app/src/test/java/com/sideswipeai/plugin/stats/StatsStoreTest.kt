package com.sideswipeai.plugin.stats

import org.junit.Assert.*
import org.junit.Test
import java.io.File

class StatsStoreTest {
    private fun tmp(): File = File.createTempFile("stats", ".json").also { it.delete(); it.deleteOnExit() }
    private fun rec(id: Long, strat: String = "smart", kind: String = "manual", frames: Int = 100, miss: Int = 10, t: Int = 4, g: Int = 3) =
        SessionRecord(id, strat, true, id, 60_000, frames, miss, 0, t, g, kind, "x")

    @Test fun saveAndReload_roundTrip() {
        val f = tmp(); val a = StatsStore(f); a.add(rec(1)); a.add(rec(2, "chase"))
        val b = StatsStore(f); b.load()
        assertEquals(2, b.all().size); assertEquals(a.all(), b.all())
    }

    @Test fun unknownResult_isNullNotZero() {
        val s = StatsStore(tmp()); s.add(rec(1))
        val sm = s.summaries().single()
        assertNull(sm.winRate); assertNull(sm.goalsFor); assertNull(sm.goalsAgainst); assertEquals(0, sm.knownResults)
    }

    @Test fun noTouches_goodRateIsNull() {
        val s = StatsStore(tmp()); s.add(rec(1, t = 0, g = 0))
        assertNull(s.summaries().single().goodTouchRate)
    }

    @Test fun winRate_onlyOverKnownResults() {
        val s = StatsStore(tmp()); s.add(rec(1)); s.add(rec(2)); s.add(rec(3))
        assertTrue(s.setLastResult("win", 3, 1))            // الجلسة 3 فقط معروفة النتيجة
        val sm = s.summaries().single()
        assertEquals(1, sm.knownResults); assertEquals(1.0, sm.winRate!!, 1e-9)
        assertEquals(3, sm.goalsFor); assertEquals(1, sm.goalsAgainst)
    }

    @Test fun invalidResult_rejected() {
        val s = StatsStore(tmp()); assertFalse(s.setLastResult("win", null, null))   // لا جلسات
        s.add(rec(1)); assertFalse(s.setLastResult("bogus", null, null)); assertFalse(s.setLastResult("win", -1, 0))
    }

    @Test fun summariesSeparatedByStrategy() {
        val s = StatsStore(tmp()); s.add(rec(1, "smart")); s.add(rec(2, "chase", kind = "control")); s.add(rec(3, "chase"))
        val m = s.summaries().associateBy { it.strategy }
        assertEquals(1, m["smart"]!!.sessions); assertEquals(2, m["chase"]!!.sessions); assertEquals(1, m["chase"]!!.controlStops)
    }

    @Test fun corruptFile_backedUpAndEmpty() {
        val f = tmp(); f.writeText("{not json")
        val s = StatsStore(f); s.load()
        assertTrue(s.all().isEmpty()); assertTrue(s.loadError.isNotEmpty()); assertTrue(File(f.path + ".bak").exists())
        File(f.path + ".bak").delete()
    }
}
