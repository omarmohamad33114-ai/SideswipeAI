package com.sideswipeai.plugin.ai

import org.junit.Assert.*
import org.junit.Test

class DecisionEngineTest {
    private fun eng(right: Boolean = true) = DecisionEngine(AiConfig(attackRight = right))

    @Test fun ballAhead_approachesRightWithBoost() {
        val d = eng().decide(World(10_000, Obj(0.6f, 0.8f, 0f, 0f), Obj(0.3f, 0.8f, 0f, 0f), null, 1))
        assertEquals("APPROACH", d.mode); assertTrue(d.right); assertFalse(d.left); assertTrue(d.boost)
    }

    @Test fun meAheadOfBall_goesBackLeft() {
        val d = eng().decide(World(10_000, Obj(0.4f, 0.8f, 0f, 0f), Obj(0.7f, 0.8f, 0f, 0f), null, -1))
        assertEquals("AIM", d.mode); assertTrue(d.left); assertFalse(d.right)
    }

    @Test fun ballAboveAndClose_jumps() {
        val d = eng().decide(World(10_000, Obj(0.52f, 0.55f, 0f, 0f), Obj(0.5f, 0.8f, 0f, 0f), null, 1))
        assertEquals("HIGH_BALL", d.mode); assertTrue(d.jump)
    }

    @Test fun noBall_searchesWithoutBoost() {
        val d = eng().decide(World(10_000, null, Obj(0.2f, 0.8f, 0f, 0f), null, 1))
        assertEquals("SEARCH", d.mode); assertFalse(d.boost)
    }

    @Test fun ballLostTooLong_safeStopNoInputs() {
        val e = eng(); val me = Obj(0.2f, 0.8f, 0f, 0f)
        e.decide(World(10_000, Obj(0.6f, 0.8f, 0f, 0f), me, null, 1))
        e.decide(World(10_100, null, me, null, 1))
        val d = e.decide(World(15_000, null, me, null, 1))
        assertEquals("SAFE", d.mode)
        assertFalse(d.left || d.right || d.boost || d.jump)
    }

    @Test fun lowConfidenceBall_treatedAsMissing() {
        val d = eng().decide(World(10_000, Obj(0.6f, 0.8f, 0f, 0f, conf = 0.1f), Obj(0.3f, 0.8f, 0f, 0f), null, 1))
        assertEquals("SEARCH", d.mode)
    }

    @Test fun lowConfidenceCar_safe() {
        val d = eng().decide(World(10_000, Obj(0.6f, 0.8f, 0f, 0f), Obj(0.3f, 0.8f, 0f, 0f, conf = 0.1f), null, 1))
        assertEquals("SAFE", d.mode)
    }

    @Test fun ballHeadingToOwnGoal_defends() {
        val d = eng().decide(World(10_000, Obj(0.2f, 0.8f, -0.5f, 0f), Obj(0.5f, 0.8f, 0f, 0f), null, -1))
        assertEquals("DEFENSE", d.mode)
    }

    @Test fun chaseBaseline_neverJumps() {
        val c = ChaseStrategy(AiConfig())
        val d = c.decide(World(10_000, Obj(0.52f, 0.55f, 0f, 0f), Obj(0.5f, 0.8f, 0f, 0f), null, 1))
        assertFalse(d.jump)
    }
}
