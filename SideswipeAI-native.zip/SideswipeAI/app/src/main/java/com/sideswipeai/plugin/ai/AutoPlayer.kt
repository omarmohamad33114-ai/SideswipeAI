package com.sideswipeai.plugin.ai

import android.os.Handler
import android.os.Looper
import com.sideswipeai.plugin.ErrLog
import com.sideswipeai.plugin.ScreenCaptureService
import com.sideswipeai.plugin.TouchInjectorService
import com.sideswipeai.plugin.control.TouchController
import com.sideswipeai.plugin.control.TouchController.Btn
import com.sideswipeai.plugin.stats.SessionRecord
import com.sideswipeai.plugin.stats.StatsStore
import com.sideswipeai.plugin.vision.VisionEngine
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import kotlin.math.abs
import kotlin.math.sqrt

/** يربط الرؤية بالقرار بالتحكم + شبكات الأمان (إيقاف فوري، انتهاء الإطارات، مدة قصوى) + سجل JSONL. */
object AutoPlayer {
    @Volatile var running = false
    @Volatile var cfg = AiConfig()
    @Volatile private var mode = "IDLE"
    @Volatile private var reason = ""
    @Volatile private var err = ""
    @Volatile private var armedAt = 0L
    @Volatile private var lastVisionAt = 0L
    @Volatile private var touches = 0
    @Volatile private var good = 0
    @Volatile var logPath = ""
    @Volatile var stats: StatsStore? = null
    @Volatile private var frames = 0
    @Volatile private var ballMiss = 0
    @Volatile private var safeFrames = 0
    private var sessionStrategy = "smart"
    private var sessionRight = true

    /** يفتح (مرة واحدة) مخزن الإحصائيات في مجلد ملفات التطبيق. */
    @Synchronized fun ensureStats(dir: File?): StatsStore? {
        if (stats == null && dir != null) { stats = StatsStore(File(dir, "stats.json")).also { it.load() } }
        return stats
    }
    private var startedAt = 0L
    private var engine: Strategy = Strategies.create(cfg.strategy, cfg)
    private var lastSet: Set<Btn> = emptySet()
    private var jumpUntil = 0L
    private var prevBall: Obj? = null
    private var lastTouchAt = 0L
    private var log: BufferedWriter? = null
    private var steerText = "-"
    private var boostOn = false
    private val main = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val now = System.currentTimeMillis()
            if (now >= armedAt) {
                if (now - startedAt > cfg.maxRunMs) { emergencyStop("انتهت المدة القصوى", "timeout"); return }
                if (now - lastVisionAt > cfg.staleMs) {
                    TouchController.setDesired(emptySet()); mode = "IDLE"; reason = "لا توجد إطارات حديثة"
                }
            }
            main.postDelayed(this, 200)
        }
    }

    @Synchronized fun start(delayMs: Long, dir: File?): String {
        if (running) return "البوت يعمل بالفعل"
        if (ScreenCaptureService.status != "running") return "ابدأ المراقبة أولًا"
        if (TouchInjectorService.instance == null) return "فعّل خدمة التحكم من إعدادات إمكانية الوصول"
        if (!TouchController.ready()) return "عايِر الأزرار الأربعة (يسار، يمين، قفز، بوست)"
        val now = System.currentTimeMillis()
        VisionEngine.enabled = true
        if (ScreenCaptureService.intervalMs > 150) ScreenCaptureService.intervalMs = 150   // قرار أسرع أثناء اللعب
        engine = Strategies.create(cfg.strategy, cfg)
        armedAt = now + delayMs; startedAt = armedAt; lastVisionAt = armedAt
        touches = 0; good = 0; prevBall = null; err = ""
        frames = 0; ballMiss = 0; safeFrames = 0; sessionStrategy = cfg.strategy; sessionRight = cfg.attackRight
        ensureStats(dir)
        openLog(dir)
        TouchController.start()
        running = true; mode = "ARMED"; reason = "جاهز، ابدأ اللعبة"
        main.removeCallbacks(tick)
        main.post(tick)
        return ""
    }

    /** kind: manual | control | capture | timeout — يُستخدم في الإحصائيات لتصنيف سبب الإيقاف. */
    @Synchronized fun emergencyStop(why: String, kind: String = "manual") {
        val was = running
        running = false
        TouchController.stop()
        if (was) {
            mode = "STOPPED"; reason = why; ErrLog.add("stop", why)
            recordSession(kind, why)
        }
        try { log?.flush(); log?.close() } catch (_: Exception) {}
        log = null
    }

    fun onControllerError(msg: String) { err = msg }

    /** يحفظ سجل الجلسة؛ الجلسات التي لم تُحلَّل فيها أي إطارات لا تُسجَّل (لا بيانات حقيقية). */
    private fun recordSession(kind: String, why: String) {
        if (frames == 0) return
        try {
            stats?.add(SessionRecord(startedAt, sessionStrategy, sessionRight, startedAt,
                (System.currentTimeMillis() - startedAt).coerceAtLeast(0), frames, ballMiss, safeFrames,
                touches, good, kind, why))
        } catch (e: Exception) { ErrLog.add("stats", e.message ?: "تعذر حفظ الإحصائيات") }
    }

    fun onVision(json: String) {
        if (!running) return
        val now = System.currentTimeMillis()
        lastVisionAt = now
        if (now < armedAt) { mode = "ARMED"; return }
        // اللعبة أفقية فقط: إطار عمودي يعني أنها ليست في المقدمة، فلا نرسل لمسات
        if (ScreenCaptureService.frameW in 1 until ScreenCaptureService.frameH) {
            TouchController.setDesired(emptySet()); mode = "IDLE"; reason = "الشاشة عمودية: اللعبة ليست في المقدمة"; return
        }
        try {
            val o = JSONObject(json).getJSONObject("objs")
            fun obj(k: String) = o.optJSONObject(k)?.let {
                Obj(it.getDouble("x").toFloat(), it.getDouble("y").toFloat(), it.getDouble("vx").toFloat(), it.getDouble("vy").toFloat(),
                    it.optDouble("conf", 1.0).toFloat(), it.optBoolean("vok", false))
            }
            val facing = o.optJSONObject("my_car")?.optInt("facing", 0) ?: 0
            val w = World(now, obj("ball"), obj("my_car"), obj("opp_car"), facing)
            engine.cfg = cfg
            val d = engine.decide(w)
            frames++
            if (w.ball == null || w.ball.conf < cfg.minConf) ballMiss++
            if (d.mode == "SAFE") safeFrames++
            apply(d, now)
            trackTouch(w)
            writeLog(w, d)
        } catch (e: Exception) { err = e.message ?: "خطأ في التحليل"; ErrLog.add("decision", err) }
    }

    private fun apply(d: Decision, now: Long) {
        val s = HashSet<Btn>()
        if (d.left) s += Btn.LEFT
        if (d.right) s += Btn.RIGHT
        if (d.boost) s += Btn.BOOST
        lastSet = s
        if (d.jump) {
            jumpUntil = now + 130
            main.postDelayed({ if (running) TouchController.setDesired(lastSet) }, 130)
        }
        val out = HashSet(s); if (now < jumpUntil) out += Btn.JUMP
        TouchController.setDesired(out)
        mode = d.mode; reason = d.reason
        steerText = if (d.left) "يسار" else if (d.right) "يمين" else "-"
        boostOn = d.boost
    }

    /** إحصاء لمسات الكرة: تغيّر سرعتها بقوة وهي قريبة من سيارتي. جيدة = اتجهت نحو مرمى الخصم. */
    private fun trackTouch(w: World) {
        val b = w.ball; val m = w.me; val p = prevBall
        prevBall = b
        if (b == null || m == null || p == null) return
        val dv = sqrt((b.vx - p.vx) * (b.vx - p.vx) + (b.vy - p.vy) * (b.vy - p.vy))
        if (abs(b.x - m.x) < 0.06f && abs(b.y - m.y) < 0.1f && dv > 0.3f && w.t - lastTouchAt > 500) {
            lastTouchAt = w.t; touches++
            if (b.vx * (if (cfg.attackRight) 1 else -1) > 0.05f) good++
        }
    }

    private fun openLog(dir: File?) {
        try {
            if (dir == null) return
            dir.mkdirs()
            val f = File(dir, "session_${System.currentTimeMillis()}.jsonl")
            log = BufferedWriter(FileWriter(f)); logPath = f.absolutePath
            log!!.write("{\"header\":true,\"strategy\":\"${cfg.strategy}\",\"attackRight\":${cfg.attackRight},\"t\":${System.currentTimeMillis()}}\n")
        } catch (e: Exception) { err = "تعذر فتح السجل"; ErrLog.add("log", err) }
    }

    private fun writeLog(w: World, d: Decision) {
        val l = log ?: return
        fun a(o: Obj?) = if (o == null) "null" else "[${o.x},${o.y},${o.vx},${o.vy}]"
        try {
            l.write("{\"t\":${w.t},\"mode\":\"${d.mode}\",\"L\":${d.left},\"R\":${d.right},\"B\":${d.boost},\"J\":${d.jump}," +
                "\"ball\":${a(w.ball)},\"me\":${a(w.me)},\"opp\":${a(w.opp)},\"touches\":$touches,\"good\":$good}\n")
        } catch (_: Exception) {}
    }

    fun statusJson(): String {
        val now = System.currentTimeMillis()
        return JSONObject().put("running", running).put("mode", mode).put("reason", reason)
            .put("steer", steerText).put("boost", boostOn).put("touches", touches).put("good", good)
            .put("armed_in", if (running && now < armedAt) (armedAt - now) / 1000 else 0)
            .put("err", if (err.isNotEmpty()) err else TouchController.lastError)
            .put("strategy", engine.name).put("log", logPath).toString()
    }
}
