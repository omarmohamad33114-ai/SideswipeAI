package com.sideswipeai.plugin.ai

import kotlin.math.abs

/** عقد موحّد لأي استراتيجية لعب: يسمح بتبديلها ومقارنتها بنفس الواجهة. */
interface Strategy {
    val name: String
    var cfg: AiConfig
    fun decide(w: World): Decision
}

object Strategies {
    val names = listOf("smart", "chase")
    fun create(name: String, cfg: AiConfig): Strategy = when (name) {
        "chase" -> ChaseStrategy(cfg)
        else -> DecisionEngine(cfg)
    }
}

/** خط الأساس: يطارد الكرة دائمًا بلا توقع ولا دفاع ولا قفز. يمثل بوتًا مبتدئًا للمقارنة. */
class ChaseStrategy(override var cfg: AiConfig = AiConfig()) : Strategy {
    override val name = "chase"
    override fun decide(w: World): Decision {
        val me = w.me?.takeIf { it.conf >= cfg.minConf } ?: return Decision("SAFE", reason = "سيارتي غير موثوقة")
        val ball = w.ball?.takeIf { it.conf >= cfg.minConf } ?: return Decision("SAFE", reason = "الكرة غير ظاهرة")
        val e = ball.x - me.x
        val s = if (abs(e) < cfg.deadzone) 0 else if (e > 0) 1 else -1
        return Decision("CHASE", left = s < 0, right = s > 0, boost = s != 0 && abs(e) > 0.15f, reason = "مطاردة الكرة")
    }
}
