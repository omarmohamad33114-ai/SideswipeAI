package com.sideswipeai.plugin

import com.sideswipeai.plugin.ai.AutoPlayer
import com.sideswipeai.plugin.vision.VisionEngine

/** نقطة ربط واحدة تُستدعى من التطبيق ومن خدمة الفقاعة (لا حالة مكررة: كله يُقرأ من المصادر الأصلية). */
object AppState {
    @Volatile private var wired = false

    @Synchronized fun ensureWired() {
        if (wired) return
        wired = true
        ScreenCaptureService.frameListener = { VisionEngine.process(it) }
        VisionEngine.resultListener = { AutoPlayer.onVision(it) }
    }
}
