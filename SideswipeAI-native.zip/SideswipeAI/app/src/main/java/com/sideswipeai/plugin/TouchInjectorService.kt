package com.sideswipeai.plugin

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.sideswipeai.plugin.ai.AutoPlayer

/** وسيلة التحكم المسموحة: AccessibilityService.dispatchGesture (يفعّلها المستخدم يدويًا). */
class TouchInjectorService : AccessibilityService() {
    companion object { @Volatile var instance: TouchInjectorService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        AutoPlayer.emergencyStop("تم إيقاف خدمة التحكم", "control")
        return super.onUnbind(intent)
    }
    override fun onDestroy() { instance = null; AutoPlayer.emergencyStop("أُنهيت خدمة التحكم", "control"); super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { AutoPlayer.emergencyStop("انقطعت خدمة التحكم", "control") }

    /** حجم الشاشة الحقيقي الحالي بالبكسل (يتبع التدوير). */
    fun screenSize(): Pair<Int, Int> {
        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return m.widthPixels to m.heightPixels
    }

    fun press(x: Float, y: Float, durationMs: Long): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, durationMs.coerceAtLeast(1)))
            .build()
        return dispatchGesture(g, null, null)
    }
}
