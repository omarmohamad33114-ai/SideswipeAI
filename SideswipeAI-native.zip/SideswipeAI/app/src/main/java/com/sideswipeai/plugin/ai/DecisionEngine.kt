package com.sideswipeai.plugin.ai

import kotlin.math.abs
import kotlin.math.min

/**
 * استراتيجية "smart": نظام حالات + توقع مسار الكرة + نقطة اعتراض + توقف آمن.
 * قواعد صريحة (لا تعلّم آلي). نقي بلا اعتماد على Android فيمكن اختباره على JVM.
 * الافتراض: لعبة جانبية، الأرض قرب الأسفل، المرمى عند طرفي x=0 و x=1 (جهة الهجوم من الإعدادات، وليست مكتشفة بالرؤية).
 * الحالات: SEARCH, AIM (التموضع خلف الكرة), APPROACH, STRIKE, DEFENSE, HIGH_BALL, AIR, RECOVER, UNSTICK, SAFE.
 * الاعتراض ليس حالة مستقلة: نقطة الاعتراض هي هدف التوجيه في كل الحالات.
 */
class DecisionEngine(override var cfg: AiConfig = AiConfig()) : Strategy {
    override val name = "smart"
    private var groundY = -1f
    private var lastJumpAt = 0L
    private var lastAirAt = -100_000L
    private var lastSteer = 0
    private var steerSince = 0L
    private var lostSince = 0L
    private var last: Decision? = null
    private var refX = -1f
    private var refT = 0L
    private var unstickUntil = 0L
    private var unstickDir = 0

    override fun decide(w: World): Decision { val d = compute(w); last = d; return d }

    /** موضع الكرة المتوقع بعد t ثانية: جاذبية + ارتداد جدران وأرض. بلا سرعة موثوقة نرجع الموضع الحالي. */
    private fun predict(ball: Obj, t: Float): Pair<Float, Float> {
        if (!ball.vOk) return ball.x to ball.y
        var x = ball.x; var y = ball.y; var vx = ball.vx; var vy = ball.vy
        val floor = if (groundY > 0) groundY else 0.9f
        var tt = 0f
        while (tt < t) {
            val dt = min(0.05f, t - tt)
            vy += cfg.gravity * dt
            x += vx * dt; y += vy * dt
            if (x < 0f) { x = -x; vx = -vx * 0.8f } else if (x > 1f) { x = 2f - x; vx = -vx * 0.8f }
            if (y > floor) { y = floor; vy = if (abs(vy) < 0.25f) 0f else -vy * 0.6f }
            if (y < 0f) { y = 0f; vy = -vy * 0.5f }
            tt += dt
        }
        return x to y
    }

    /** أبكر نقطة تستطيع السيارة بلوغها أفقيًا قبل الكرة (x, y, t). */
    private fun intercept(ball: Obj, me: Obj): Triple<Float, Float, Float> {
        var t = 0f
        while (t <= 1.2f) {
            val p = predict(ball, t)
            if (abs(p.first - me.x) <= cfg.carSpeed * t + 0.04f) return Triple(p.first, p.second, t)
            t += 0.1f
        }
        val p = predict(ball, 0.6f)
        return Triple(p.first, p.second, 0.6f)
    }

    private fun compute(w: World): Decision {
        val now = w.t
        val me = w.me?.takeIf { it.conf >= cfg.minConf }
            ?: return Decision("SAFE", reason = "سيارتي غير ظاهرة أو غير موثوقة: توقف آمن")
        val dir = if (cfg.attackRight) 1 else -1

        if (groundY < 0) groundY = me.y
        if (abs(me.vy) < 0.03f) groundY += (me.y - groundY) * 0.05f
        val airborne = me.y < groundY - 0.06f
        if (airborne) lastAirAt = now
        val recovering = !airborne && now - lastAirAt < 300

        if (now < unstickUntil)
            return Decision("UNSTICK", left = unstickDir < 0, right = unstickDir > 0, reason = "تحرير السيارة")

        // كشف التعلّق: نريد الحركة لكن الموضع لا يتغير
        if (refX < 0) { refX = me.x; refT = now }
        else if (now - refT >= 1500) {
            val active = last?.let { it.left || it.right || it.boost } ?: false
            if (active && !airborne && abs(me.x - refX) < 0.01f) {
                unstickUntil = now + 600
                unstickDir = if (lastSteer != 0) -lastSteer else -dir
            }
            refX = me.x; refT = now
        }

        val ball = w.ball?.takeIf { it.conf >= cfg.minConf }
        if (ball == null) {
            if (lostSince == 0L) lostSince = now
            val lostFor = now - lostSince
            val prev = last
            if (lostFor < cfg.ballLostHoldMs && prev != null)
                return prev.copy(jump = false, reason = "الكرة مفقودة مؤقتًا")
            if (lostFor > cfg.ballLostSafeMs)
                return Decision("SAFE", reason = "الكرة غير ظاهرة منذ مدة: توقف آمن")
            val e = 0.5f - me.x
            val s = if (abs(e) < 0.05f) 0 else if (e > 0) 1 else -1
            return Decision("SEARCH", left = s < 0, right = s > 0, reason = "بحث عن الكرة")
        }
        lostSince = 0L

        val (px, py, tHit) = intercept(ball, me)
        val dx = px - me.x
        val ballAbove = groundY - py
        val ownGoalX = if (dir == 1) 0.02f else 0.98f
        val ballOnOwnSide = (ball.x - 0.5f) * dir < -0.2f
        val ballToOwnGoal = ball.vOk && ball.vx * dir < -0.05f
        val opp = w.opp?.takeIf { it.conf >= cfg.minConf }
        val oppCloser = opp != null && abs(opp.x - ball.x) < abs(me.x - ball.x) - 0.05f
        val danger = ballOnOwnSide && (ballToOwnGoal || oppCloser)
        val behind = (me.x - px) * dir < 0   // أنا في جهة مرماي من الكرة، فأستطيع ضربها نحو مرمى الخصم

        val mode = when {
            airborne -> "AIR"
            danger -> "DEFENSE"
            recovering -> "RECOVER"
            ballAbove > 0.12f -> "HIGH_BALL"
            !behind -> "AIM"
            abs(dx) > 0.15f -> "APPROACH"
            else -> "STRIKE"
        }

        val tx = when (mode) {
            "DEFENSE" -> if (abs(px - ownGoalX) > 0.55f) ownGoalX + dir * 0.18f else px - dir * 0.04f
            "AIM" -> px - dir * cfg.behindOffset
            "STRIKE" -> px + dir * 0.02f
            else -> px - dir * 0.03f        // APPROACH / HIGH_BALL / RECOVER / AIR
        }
        val err = tx - me.x

        var steer = if (abs(err) < cfg.deadzone) 0 else if (err > 0) 1 else -1
        if (airborne) steer = 0                      // لا دوران عشوائي في الهواء
        if (steer != 0 && lastSteer != 0 && steer != lastSteer && now - steerSince < cfg.minHoldMs) steer = lastSteer
        if (steer != lastSteer) { lastSteer = steer; steerSince = now }

        val boost = if (!airborne) {
            val facingOk = w.meFacing == 0 || w.meFacing == steer
            steer != 0 && facingOk && !recovering && (abs(err) > 0.12f || mode == "STRIKE")
        } else ballAbove > 0.08f && abs(dx) < 0.2f

        var jump = false
        if (!airborne && ballAbove > 0.12f && tHit < 0.35f && now - lastJumpAt > cfg.jumpCooldownMs) {
            val relX = px - (me.x + (if (me.vOk) me.vx else 0f) * 0.25f)
            if (abs(relX) < 0.08f) { jump = true; lastJumpAt = now }
        }

        val why = when (mode) {
            "AIR" -> "في الهواء"
            "DEFENSE" -> "دفاع: الكرة تقترب من مرماي"
            "RECOVER" -> "استعادة الوضعية بعد الهبوط"
            "HIGH_BALL" -> "كرة مرتفعة: التموضع تحتها وتوقيت القفز"
            "AIM" -> "التفاف خلف الكرة"
            "APPROACH" -> "اقتراب من نقطة الاعتراض"
            else -> "تسديد نحو مرمى الخصم"
        }
        return Decision(mode, left = steer < 0, right = steer > 0, boost = boost, jump = jump, reason = why)
    }
}
