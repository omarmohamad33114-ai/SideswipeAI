package com.sideswipeai.plugin.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.sideswipeai.plugin.ErrLog
import com.sideswipeai.plugin.TouchInjectorService
import com.sideswipeai.plugin.ai.AutoPlayer
import java.util.concurrent.ConcurrentHashMap

/**
 * طبقة التحكم: تحوّل مجموعة أزرار مطلوبة إلى ضغطات مستمرة عبر dispatchGesture.
 * تُقسَّم الضغطة إلى مقاطع (SEG) متصلة بـ willContinue كي لا يُرفع الإصبع بين المقاطع.
 */
object TouchController {
    enum class Btn(val key: String) { LEFT("btn_left"), RIGHT("btn_right"), JUMP("btn_jump"), BOOST("btn_boost") }

    private const val SEG = 100L
    val points = ConcurrentHashMap<Btn, PointF>()      // إحداثيات معيارية 0..1 من الشاشة
    @Volatile var enabled = false
    @Volatile var lastError = ""
    @Volatile private var desired: Set<Btn> = emptySet()

    // تُستخدم على الخيط الرئيسي فقط
    private val held = HashMap<Btn, GestureDescription.StrokeDescription>()
    private var inFlight = false
    private var sentAt = 0L
    /** متوسط التأخير الإضافي لإرسال لمسة فوق مدة المقطع (مللي ثانية) - قياس فعلي. */
    @Volatile var overheadMs = 0L
    private var fails = 0
    private val main = Handler(Looper.getMainLooper())

    fun setPoint(key: String, x: Float, y: Float) {
        Btn.values().firstOrNull { it.key == key }?.let { points[it] = PointF(x, y) }
    }
    fun pointsJson(): String =
        points.entries.joinToString(",", "{", "}") { "\"${it.key.key}\":[${it.value.x},${it.value.y}]" }
    fun ready() = Btn.values().all { points.containsKey(it) }

    fun start() { enabled = true; fails = 0; lastError = "" }
    fun stop() { enabled = false; desired = emptySet(); main.post { pump() }; main.postDelayed({ pump() }, 1700) }   // يحرّر الأزرار المضغوطة
    fun setDesired(s: Set<Btn>) { desired = s; main.post { pump() } }

    private fun fail(msg: String) {
        lastError = msg; enabled = false; desired = emptySet(); held.clear(); inFlight = false
        ErrLog.add("control", msg)
        AutoPlayer.onControllerError(msg)
        AutoPlayer.emergencyStop("خطأ في التحكم: $msg", "control")
    }

    private fun pump() {
        if (inFlight) {
            if (SystemClock.uptimeMillis() - sentAt < 1500) return
            inFlight = false; held.clear(); ErrLog.add("control", "تأخر رد النظام على اللمسة")
        }
        val want = if (enabled) desired else emptySet()
        if (want.isEmpty() && held.isEmpty()) return
        val svc: AccessibilityService = TouchInjectorService.instance
            ?: run { if (enabled) fail("خدمة التحكم غير مفعّلة"); held.clear(); return }
        val (w, h) = TouchInjectorService.instance!!.screenSize()
        val b = GestureDescription.Builder()
        val next = HashMap<Btn, GestureDescription.StrokeDescription>()
        for (btn in (held.keys + want)) {
            val pt = points[btn] ?: continue
            val path = Path().apply { moveTo(pt.x * w, pt.y * h) }
            val keep = btn in want
            val prev = held[btn]
            val s = if (prev == null) GestureDescription.StrokeDescription(path, 0L, SEG, keep)
                    else prev.continueStroke(path, 0L, SEG, keep)
            b.addStroke(s)
            if (keep) next[btn] = s
        }
        inFlight = true; sentAt = SystemClock.uptimeMillis()
        val ok = svc.dispatchGesture(b.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                val d = (SystemClock.uptimeMillis() - sentAt - SEG).coerceAtLeast(0)
                overheadMs = if (overheadMs == 0L) d else (overheadMs * 8 + d * 2) / 10
                held.clear(); held.putAll(next); inFlight = false; fails = 0; pump()
            }
            override fun onCancelled(g: GestureDescription?) {
                held.clear(); inFlight = false
                if (++fails >= 5) fail("تكرر إلغاء اللمسات") else pump()
            }
        }, main)
        if (!ok) { inFlight = false; held.clear(); fail("رفض النظام إرسال اللمسة") }
    }
}
