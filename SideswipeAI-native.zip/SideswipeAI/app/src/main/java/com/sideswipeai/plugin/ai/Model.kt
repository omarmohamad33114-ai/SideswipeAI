package com.sideswipeai.plugin.ai

/**
 * إحداثيات معيارية 0..1 (x يمين، y أسفل). السرعة بوحدة/ثانية.
 * conf: ثقة الاكتشاف 0..1 (تقدير استدلالي وليس احتمالًا معايَرًا).
 * vOk: هل السرعة مبنية على عدد كافٍ من الإطارات المتتالية؟ إن كانت false فالسرعة غير موثوقة.
 */
data class Obj(
    val x: Float, val y: Float, val vx: Float, val vy: Float,
    val conf: Float = 1f, val vOk: Boolean = true
)

data class World(val t: Long, val ball: Obj?, val me: Obj?, val opp: Obj?, val meFacing: Int = 0)

/**
 * mode: SEARCH | AIM | APPROACH | STRIKE | DEFENSE | HIGH_BALL | AIR | RECOVER | UNSTICK | SAFE | IDLE | CHASE
 * SAFE = لا مدخلات إطلاقًا لأن بيانات الرؤية غير موثوقة.
 */
data class Decision(
    val mode: String,
    val left: Boolean = false,
    val right: Boolean = false,
    val boost: Boolean = false,
    val jump: Boolean = false,
    val reason: String = ""
)

data class AiConfig(
    var attackRight: Boolean = true,
    var lookaheadSec: Float = 0.3f,
    var deadzone: Float = 0.02f,
    var minHoldMs: Long = 150,
    var behindOffset: Float = 0.12f,
    var jumpCooldownMs: Long = 900,
    var staleMs: Long = 700,
    var maxRunMs: Long = 10 * 60_000L,
    var strategy: String = "smart",
    /** أقل ثقة لاعتبار الاكتشاف صالحًا */
    var minConf: Float = 0.35f,
    /** تسارع السقوط المعياري (y/ث²) — تقدير غير مقاس، يحتاج ضبطًا من سجلات حقيقية */
    var gravity: Float = 1.2f,
    /** سرعة السيارة الأفقية المعيارية (x/ث) — تقدير غير مقاس */
    var carSpeed: Float = 0.45f,
    /** الكرة غير ظاهرة: بعد هذه المدة ننتقل من الانتظار إلى البحث البطيء */
    var ballLostHoldMs: Long = 500,
    /** الكرة غير ظاهرة: بعد هذه المدة نتوقف تمامًا (SAFE) */
    var ballLostSafeMs: Long = 4000
)
