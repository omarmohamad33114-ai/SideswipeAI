package com.sideswipeai.plugin

import android.content.Context
import com.sideswipeai.plugin.ai.AutoPlayer
import com.sideswipeai.plugin.ai.Strategies
import com.sideswipeai.plugin.control.TouchController
import com.sideswipeai.plugin.vision.VisionEngine
import org.json.JSONObject

/** حفظ/استرجاع المعايرة والإعدادات (SharedPreferences) + مواضع الأزرار الافتراضية. */
object Store {
    private const val P = "sideswipe"

    /**
     * مواضع افتراضية تقريبية (معيارية 0..1) لأزرار Rocket League Sideswipe في الوضع الأفقي.
     * غير مؤكدة على جهاز حقيقي: إن لم تستجب اللعبة كما ينبغي استخدم "معايرة" في التطبيق.
     */
    private val DEFAULT_BUTTONS = mapOf(
        "btn_left" to floatArrayOf(0.08f, 0.82f),
        "btn_right" to floatArrayOf(0.20f, 0.82f),
        "btn_jump" to floatArrayOf(0.80f, 0.82f),
        "btn_boost" to floatArrayOf(0.92f, 0.70f)
    )

    @Volatile var usingDefaultButtons = true

    fun load(ctx: Context) {
        val sp = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
        try { sp.getString("targets", null)?.let { VisionEngine.setTargetsJson(it) } } catch (e: Exception) { ErrLog.add("store", "targets: ${e.message}") }
        var loaded = false
        try {
            sp.getString("buttons", null)?.let { s ->
                val o = JSONObject(s)
                for (k in o.keys()) { val a = o.getJSONArray(k); TouchController.setPoint(k, a.getDouble(0).toFloat(), a.getDouble(1).toFloat()) }
                loaded = TouchController.ready()
            }
        } catch (e: Exception) { ErrLog.add("store", "buttons: ${e.message}") }
        usingDefaultButtons = !loaded
        if (!loaded) applyDefaultButtons()
        val strat = sp.getString("strategy", "smart") ?: "smart"
        AutoPlayer.cfg = AutoPlayer.cfg.copy(
            attackRight = sp.getBoolean("attackRight", true),
            strategy = if (strat in Strategies.names) strat else "smart"
        )
    }

    fun applyDefaultButtons() {
        DEFAULT_BUTTONS.forEach { (k, v) -> TouchController.setPoint(k, v[0], v[1]) }
        usingDefaultButtons = true
    }

    /** يحفظ المعايرة الحالية (الألوان + الأزرار). */
    fun saveCalibration(ctx: Context, buttonsCalibrated: Boolean) {
        if (buttonsCalibrated) usingDefaultButtons = false
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
            .putString("targets", VisionEngine.targetsJson())
            .putString("buttons", TouchController.pointsJson())
            .apply()
    }

    fun saveConfig(ctx: Context) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
            .putBoolean("attackRight", AutoPlayer.cfg.attackRight)
            .putString("strategy", AutoPlayer.cfg.strategy)
            .apply()
    }
}
