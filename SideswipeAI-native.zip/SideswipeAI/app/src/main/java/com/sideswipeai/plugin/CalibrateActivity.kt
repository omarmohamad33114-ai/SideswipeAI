package com.sideswipeai.plugin

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.sideswipeai.plugin.vision.VisionEngine

/**
 * معايرة اختيارية على لقطة مجمّدة: انتقل للعبة، انتظر 5 ثوانٍ، ثم المس الكرة والسيارتين والأزرار الأربعة بالترتيب.
 */
class CalibrateActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val steps = listOf(
        "ball" to "المس الكرة",
        "my_car" to "المس سيارتك",
        "opp_car" to "المس سيارة الخصم",
        "btn_left" to "المس زر اليسار",
        "btn_right" to "المس زر اليمين",
        "btn_jump" to "المس زر القفز",
        "btn_boost" to "المس زر البوست"
    )
    private var idx = 0
    private var buttonsTouched = 0
    private lateinit var prompt: TextView
    private lateinit var image: ImageView
    private lateinit var start: Button
    private val poll = object : Runnable {
        override fun run() {
            val jpg = VisionEngine.frozenJpeg
            if (jpg != null) { showFrame(jpg); return }
            ui.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0E121B.toInt()); setPadding(16, 12, 16, 12) }
        prompt = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f
            text = "اضغط «ابدأ» ثم انتقل إلى اللعبة (ابدأ تدريبًا) وانتظر 5 ثوانٍ ثم ارجع لهذه الشاشة"
        }
        start = Button(this).apply { text = "ابدأ (لقطة بعد 5 ثوانٍ)"; setOnClickListener { startFreeze() } }
        image = ImageView(this).apply {
            visibility = View.GONE; scaleType = ImageView.ScaleType.FIT_XY; adjustViewBounds = false
            setOnTouchListener { v, e -> if (e.action == MotionEvent.ACTION_DOWN) { onTap(e.x / v.width, e.y / v.height) }; true }
        }
        col.addView(prompt); col.addView(start); col.addView(image, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(col)
    }

    override fun onDestroy() { ui.removeCallbacks(poll); VisionEngine.clearFrozen(); super.onDestroy() }

    private fun startFreeze() {
        if (ScreenCaptureService.status != "running") { prompt.text = "التقاط الشاشة لا يعمل. ارجع واضغط اتصال"; return }
        VisionEngine.clearFrozen()
        VisionEngine.freezeAt = System.currentTimeMillis() + 5000
        prompt.text = "انتقل إلى اللعبة الآن وانتظر 5 ثوانٍ ثم ارجع إلى هنا (زر الرجوع/التطبيقات الأخيرة)"
        GameLauncher.launch(this)
        ui.removeCallbacks(poll); ui.postDelayed(poll, 6000)
    }

    private fun showFrame(jpg: ByteArray) {
        val bmp = BitmapFactory.decodeByteArray(jpg, 0, jpg.size) ?: run { prompt.text = "تعذّر قراءة اللقطة"; return }
        image.setImageBitmap(bmp); image.visibility = View.VISIBLE; start.visibility = View.GONE
        idx = 0; buttonsTouched = 0
        prompt.text = steps[0].second
    }

    private fun onTap(nx: Float, ny: Float) {
        if (idx >= steps.size) return
        val x = nx.coerceIn(0f, 1f); val y = ny.coerceIn(0f, 1f)
        val key = steps[idx].first
        if (key.startsWith("btn_")) { com.sideswipeai.plugin.control.TouchController.setPoint(key, x, y); buttonsTouched++ }
        else VisionEngine.calibrateAt(key, x, y)
        idx++
        if (idx >= steps.size) {
            Store.saveCalibration(this, buttonsTouched == 4)
            prompt.text = "تم حفظ المعايرة ✅ يمكنك الرجوع"
            ui.postDelayed({ finish() }, 1200)
        } else prompt.text = steps[idx].second
    }
}
