package com.sideswipeai.plugin

import android.app.Application

/** يهيّئ الحالة المشتركة عند إنشاء العملية (يعمل أيضًا حين تُعاد العملية بسبب الفقاعة أو خدمة الالتقاط). */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        ErrLog.dir = getExternalFilesDir(null)
        Store.load(this)
        AppState.ensureWired()
    }
}
